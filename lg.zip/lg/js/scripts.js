$(document).ready(function() {

  timer();

  $(".frames").mousemove(function(e){
    X = Math.floor(e.pageX-$(this).offset().left);
    var frame = Math.round(X/16);
    $(this).find('.li').each(function(){
        $(this).css({
          'opacity': 0,
          'z-index' : 1
        });
      });
      $('.li'+frame).css({
      'opacity': 1,
      'z-index' : 2
    });
    $(".slider1").slider({
      value: frame
    });
    console.log(frame);
  });

    /* Animation */
		$(".scroll").each(function () {
			var block = $(this);
			$(window).scroll(function() {
				var top = block.offset().top;
				var bottom = block.height()+top;
				top = top - $(window).height();
				var scroll_top = $(this).scrollTop();
				if ((scroll_top > top) && (scroll_top < bottom)) { if (!block.hasClass("animated")) { block.addClass("animated"); block.trigger('animateIn'); } }
        else { block.removeClass("animated"); block.trigger('animateOut'); }
			});
		});

    /* Time Parser */
    $(".servants em").each(function() {
      $(this).attr("data-number", parseInt($(this).text()));
    });
    $(".servants").on("animateIn", function() {
      var inter = 1;
      $(this).find("em").each(function() {
        var count = parseInt($(this).attr("data-number")),
            block = $(this),
            timeout = null,
            step = 1;
        timeout = setInterval(function() {
          if (step == 25) {
            block.text(count.toString());
            clearInterval(timeout);
          } else {
            block.text((Math.floor(count*step/25)).toString());
            step++;
          }
        }, 60);
      });
    }).on('animateOut', function() {
      $(this).find('.anim').each(function() {
        $(this).css('opacity', 0.01);
        $(this).css({'-webkit-transform': 'scale(0.7, 0.7)', '-moz-transform': 'scale(0.7, 0.7)'});
      });
    });


		var form_top = $('nav').offset().top;
		$(window).scroll(function() {
			var scroll_top = $(this).scrollTop();
			if (scroll_top > form_top) {
				$('nav').css('top', 0).css('position', 'fixed').css('z-index', 100);
			} else {
				$('nav').css('top', '').css('position', '');
			}
		});


	$(".menu_a a").click(function(event) {
		event.preventDefault(); $(".menu").animate({ "height": "toggle", "opacity": "toggle" });
	});


	$('.complete a').click(function () {
		$('.complete').fadeOut('slow', function () {
			// Animation complete.
		});
	});

	$('.error a').click(function () {
		$('.error').fadeOut('slow', function () {
			// Animation complete.
		});
	});



  
  $(".flipster").flipster({ style:'carousel', enableNavButtons: true });

  $('.li0, .li60').hover(function(){
  	$(this).siblings('.li_mark').css({
	  'opacity': 1,
	  'z-index' : 3
	});
  }).mouseout(function(){
  	$(this).siblings('.li_mark').css({
      'opacity': 0,
      'z-index' : 1
    });
  });

  $('.li_mark').hover(function(){
  	$(this).css({
	  'opacity': 1,
	  'z-index' : 3
	});
  }).mouseout(function(){
  	$(this).css({
      'opacity': 0,
      'z-index' : 1
    });
  });

  /* Prefix for Landing Pages */
	var page = $('input[name="page"]').val().match(/(?:\/)(.{1})(?:\/.*)$/i);
	if(page == null) {
		var prefix = '';
	} else {
		var prefix = '../';
	}
	var url = prefix+"send.php";

  /* Mobile & Animation */
	var mobile = navigator.userAgent.toLowerCase().match(/(iphone|ipod|ipad|android)/);
	if(mobile != null) {
		$('html').css('width', window.innerWidth + 'px');
	} else {
		$(".scroll").each(function () {
			var block = $(this);
			$(window).scroll(function() {
				var top = block.offset().top;
				var bottom = block.height()+top;
				top = top - $(window).height();
				var scroll_top = $(this).scrollTop();
				if ((scroll_top > top) && (scroll_top < bottom)) {
					if (!block.hasClass("animated")) {
						block.addClass("animated");
					}
				} else {
					block.removeClass("animated");
				}
			});
		});
		$('head').append('<link rel="stylesheet" href="'+prefix+'css/animation.css" />');
	}

  /* Forms */
	$('.button').click(function() {
		$('body').find('form:not(this)').children('label').removeClass('red');
		var utm_source = $('input[name="ref_url"]').val().match(/(?:utm_source=)(.*)(?:&utm_medium)/i);
		var utm_medium = $('input[name="ref_url"]').val().match(/(?:utm_medium=)(.*)(?:&utm_campaign)/i);
		var utm_campaign = $('input[name="ref_url"]').val().match(/(?:utm_campaign=)(.*)(?:&utm_term)/i);
		var utm_term = $('input[name="ref_url"]').val().match(/(?:utm_term=)([0-9a-zA-Zа-яА-Я%]{1,})/i);
		if(utm_source == null || utm_medium == null || utm_campaign == null || utm_term == null)
			var utms = '';
		else
			var utms = '\nutm_source='+utm_source[1]+'\nutm_medium='+utm_medium[1]+'\nutm_campaign='+utm_campaign[1]+'\nutm_term='+utm_term[1]+'\n';

		var answer = checkForm($(this).parent().get(0));
		if(answer != false) {
			var $form = $(this).parent(),
        name = $('input[name="name"]', $form).val(),
				phone = $('input[name="phone"]', $form).val(),
				email = $('input[name="email"]', $form).val(),
				ques = $('textarea[name="ques"]', $form).val(),
				sbt = $('input[type="button"]', $form).attr("name"),
				submit = $('input[name='+sbt+']', $form).val();
			var	ref = $('input[name="referer"]').val();
			var ref = ref+utms;
			var formname = $('input[name="formname"]').val();
			$.ajax({
				type: "POST",
				url: url,
				dataType: "json",
				data: "name="+name+"&phone="+phone+"&"+sbt+"="+submit+"&email="+email+"&ques="+ques+"&formname="+formname+"&ref="+ref
			}).always(function() {
				//метрики
        //ga('send', 'event', ''+sbt, ''+sbt, ''+sbt);
				popup_out();
				popup('thx', '');
        $('input[type="text"]').each(function() { $(this).val(''); });
        $('textarea').val('');
			});
		}
	});

});

/* ------------------------------------------------------------------------------------------------------------------------------------------------ */
/* Functions: */

$('.slider-range-min').draggable();

/* Popup Centration */
$(window).resize(function(){
	var Mtop = -($('.activePopup').outerHeight() / 2) + 'px';
	var Mleft = -($('.activePopup').outerWidth() / 2) + 'px';
	$('.activePopup').css({
		'margin-top' : Mtop,
		'margin-left' : Mleft,
		'left' : '50%',
		'top' : '50%'
 	});
});

/* Timer */
function timer() {
  var now = new Date();
  var newDate = new Date((now.getMonth()+1)+"/"+now.getDate()+"/"+now.getFullYear()+" 23:59:59");
  var totalRemains = (newDate.getTime()-now.getTime());
  var Days = (parseInt(parseInt(totalRemains/1000)/(24*3600)));
  var Hours = (parseInt((parseInt(totalRemains/1000) - Days*24*3600)/3600));
  var Min = (parseInt(parseInt((parseInt(totalRemains/1000) - Days*24*3600) - Hours*3600)/60));
  var Sec = parseInt((parseInt(totalRemains/1000) - Days*24*3600) - Hours*3600) - Min*60;
  if (Sec<10) { Sec="0"+Sec }
  if (Min<10) { Min="0"+Min }
  if (Hours<10) { Hours="0"+Hours }
  if (Days<10) { Days="0"+Days }
  $(".day").each(function() { $(this).text(Days); });
  $(".hour").each(function() { $(this).text(Hours); });
  $(".min").each(function() { $(this).text(Min); });
  $(".sec").each(function() { $(this).text(Sec); });
  setTimeout(timer, 1000);
}

/* Popups */
function popup(id, form, h1, h2, btn) { //onClick="popup('callback', '', '', '', '');"
	$('.popup_overlay').show();
	$('#'+id).addClass('activePopup');
	var Mtop = -($('.activePopup').outerHeight() / 2) + 'px';
	var Mleft = -($('.activePopup').outerWidth() / 2) + 'px';
	$('.activePopup').css({
		'margin-top' : Mtop,
		'margin-left' : Mleft,
		'left' : '50%',
		'top' : '50%'
 	});
  if(id == 'callback') {
 		var def_h1 = 'Заказать звонок';
 		var def_h2 = 'Оставьте заявку, и&nbsp;наш менеджер<br>свяжется с&nbsp;вами в&nbsp;ближайшее время';
 		var def_btn = 'Заказать звонок';
 	}
 	if(id == 'request') {
 		var def_h1 = 'Оставить заявку';
 		var def_h2 = 'Заполните форму,<br>и&nbsp;мы&nbsp;обязательно свяжемся с&nbsp;вами!';
 		var def_btn = 'Оставить заявку';
 	}
 	if(id == 'question') {
 		var def_h1 = 'Задать вопрос';
 		var def_h2 = 'Заполните форму,<br>и&nbsp;мы&nbsp;обязательно свяжемся с&nbsp;вами!';
 		var def_btn = 'Задать вопрос';
 	}
	if(h1 != '') {$('#'+id).find('.popup-title').html(h1);} else {$('#'+id).find('.popup-title').html(def_h1);}
	if(h2 != '') {$('#'+id).find('p').html(h2);} else {$('#'+id).find('p').html(def_h2);}
	if(btn != '') {$('#'+id).find('input[type="button"]').attr("value", btn);} else {$('#'+id).find('input[type="button"]').attr("value", def_btn);}
	$('.activePopup').show();
	$('.formname').attr("value", form);
}

/* Popup Close */
function popup_out() {
	$('.popup_overlay').hide();
	$('.popup').hide();
	$('.popup').removeClass('activePopup');
}

/* Popup formname */
function formname(name) { //onClick="formname('text');"
	$('.formname').attr("value", name);
}